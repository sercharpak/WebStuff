MusicBrainz Java API
====================

This is a Java port of the MusicBrainz API, written by 
Leigh Dodds (leigh@ldodds.com, http://www.ldodds.com)

See the package documentation for the com.ldodds.musicbrainz 
package (docs/api/index.html) for more information about using 
this API.

For more information about the MusicBrainz project see:

http://www.musicbrainz.org